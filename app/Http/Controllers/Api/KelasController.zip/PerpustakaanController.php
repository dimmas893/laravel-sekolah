<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Buku;
use App\Models\Buku_Kategori;
use App\Models\BukuRelasiKategori;
use App\Models\PerpustakaanMember;
use App\Models\Perpustakaan_Pinjam;
use App\Models\Perpustakaan_Pinjam_Rincian;
use Carbon\Carbon;
use Illuminate\Http\Request;

class PerpustakaanController extends Controller
{
    public function perpustakaan(Request $request)
    {
        $file_path = 'https://dapurkoding.my.id/';
        $yuhu = [];
        $tampung = [];
        $dataMember = PerpustakaanMember::where('user_id', $request->id_user)->first();
        if ($dataMember != null) {
            $perpustakaan_pinjam = Perpustakaan_Pinjam::where('member_id', $dataMember->id)->get();
            $id_perpustakaan_pinjam = Perpustakaan_Pinjam::where('member_id', $dataMember->id)->first();
            $rincian_buku = Perpustakaan_Pinjam_Rincian::where('perpustakaan_pinjam_id', $id_perpustakaan_pinjam->id)->first();

            foreach ($perpustakaan_pinjam as $pe) {
                $rincian_count = Perpustakaan_Pinjam_Rincian::where('perpustakaan_pinjam_id', $pe->id)->get();
                $raw['id'] = $pe->id;
                $raw['nama'] = $rincian_buku->relasiBuku->judul;
                $raw['jmlh_pinjam'] = count($rincian_count);
                $raw['avatar'] = $file_path . 'sampul/' . $rincian_buku->relasiBuku->sampul;
                $raw['tgl_kembali'] = $pe->batas_waktu;
                array_push($yuhu, $raw);
                array_push($tampung, count($rincian_count));
            }
            //dd($yuhu);
            $tampungkategori = [];
            $kategoribuku = Buku_Kategori::first();
            $bukurelasikategori = BukuRelasiKategori::where('buku_kategori_id', $kategoribuku->id)->get();
            $tampungbukurelasi = [];
            $tampungdatakategori = [];
            foreach ($bukurelasikategori as $bukurelasi) {
                array_push($tampungbukurelasi, $bukurelasi->buku_id);
                array_push($tampungdatakategori, $bukurelasi->buku_kategori_id);
            }
            $tampungdatabuku = [];
            foreach ($tampungbukurelasi as $pe) {
                array_push($tampungdatabuku, Buku::where('id', $pe)->first());
            }
            $tampungnama = [];
            foreach ($tampungdatabuku as $buku) {
                $kategori['id_buku'] = $buku->id;
                $kategori['penulis'] = $buku->penulis;
                $kategori['judul_buku'] = $buku->judul;
                $kategori['jenis'] = $buku->jenis;
                $bukurel = BukuRelasiKategori::where('buku_id', $buku->id)->get();
                $tampungnamakategori = [];
                foreach ($bukurel as $kat) {
                    array_push($tampungnamakategori, Buku_Kategori::where('id', $kat->buku_kategori_id)->first()->nama_kategori);
                }
                $kategori['kat'] = $tampungnamakategori;
                $kategori['avatar'] = $file_path . 'sampul/' . $buku->sampul;
                $kategori['view'] = (int)$buku->view;
                array_push($tampungkategori, $kategori);
            }

            $kategori['id_kategori'] = $kategoribuku->id;
            $kategori['judul_kategori'] = $kategoribuku->nama_kategori;
            // dd($kategori);
            return response()->json([
                "pinjam" => $yuhu,
                "kategori" => [
                    'id_kategori' => $kategoribuku->id,
                    'judul_kategori' => $kategoribuku->nama_kategori,
                    'buku' => $tampungkategori
                ]
            ]);
        } else {
            return response()->json([
                'error' => [
                    'Data Tidak Ditemukan',
                ],
            ], 404);
        }
    }

    public function hasilpencarian(Request $request)
    {
        $file_path = 'https://dapurkoding.my.id/';
        $judul = $request->judul_buku;
        $penulis = $request->penulis;
        $jenis = $request->jenis_buku;
        $kategori_buku = $request->kategori_buku;
        $kategorihasil = Buku_Kategori::where('nama_kategori', $kategori_buku)->first()->id;
        // dd($kategorihasil);
        // $buku = Buku::where('judul', 'like', "%" . $judul . "%")->orWhere('penulis', 'like', "%" . $penulis . "%")->where('jenis', 'like', "%" . $jenis . "%")->whereHas('buku_kategori', function ($q) use ($cari) {
        //     $q->where('nama_kategori', $matamata);
        // })->get();
        $relasibukukategori = BukuRelasiKategori::with('buku')->whereHas('buku', function ($q) use ($judul, $penulis, $jenis) {
            $q->where('judul', 'like', "%" . $judul . "%")->orWhere('penulis', 'like', "%" . $penulis . "%")->where('jenis', 'like', "%" . $jenis . "%");
        })->where('buku_kategori_id', $kategorihasil)->get();

        $tampungnamakategori = [];
        $tampungrow = [];

        foreach ($relasibukukategori as $rela) {
            array_push($tampungnamakategori, Buku_Kategori::where('id', $rela->buku_kategori_id)->first()->nama_kategori);
            $row['id_buku'] = $rela->buku_id;
            $row['penulis'] = $rela->buku->penulis;
            $row['judul_buku'] = $rela->buku->judul;
            $row['jenis'] = $rela->buku->jenis;
            $tampungnamakategori = [];
            array_push($tampungnamakategori, Buku_Kategori::where('id', $rela->buku_kategori_id)->first()->nama_kategori);
            $row['kat'] = $tampungnamakategori;
            $row['avatar'] = $file_path . 'sampul/' . $rela->buku->sampul;
            $row['view'] = $rela->buku->view;
            array_push($tampungrow, $row);
        }
        return response()->json([
            'buku' => $tampungrow
        ]);
        // dd($tampungrow);
    }

    public function detail(Request $request)
    {
        $file_path = 'https://dapurkoding.my.id/';
        $buku = Buku::with('buku_kategori')->where('id', $request->id_buku)->first();
        $bukuuu['id'] = $buku->id;
        $bukuuu['kategori'] = $buku->buku_kategori->nama_kategori;
        $bukuuu['judul'] = $buku->judul;
        $bukuuu['penulis'] = $buku->penulis;
        $bukuuu['sinopsis'] = $buku->sinopsis;
        $bukuuu['jml_hal'] = (int) $buku->jumlah_halaman;
        $bukuuu['bahasa'] = $buku->bahasa;
        $bukuuu['penerbit'] = $buku->penerbit;
        $bukuuu['isbn_no'] = $buku->isbn_no;
        $bukuuu['pinjam'] = false;
        $bukuuu['sampul'] = $file_path . 'sampul/' . $buku->sampul;

        return response()->json([
            'detail_buku' => $bukuuu
        ]);
    }

    public function pinjam(Request $request)
    {
        $batasWaktu = Carbon::now('Asia/Jakarta')->addDays(7)->format('Y-m-d');
        $memberPerpus = PerpustakaanMember::where('user_id', $request->id_user)->first();
        $tes = [
            'tanggal_peminjaman' => Carbon::now()->Format('Y-m-d'),
            'member_id' => $memberPerpus->id,
            'batas_waktu' => $batasWaktu,
        ];

        $pee = Perpustakaan_Pinjam::create($tes);
        // dd($pee);
        foreach ($request['id_buku'] as $value) {

            $create = [
                'buku_id' => $value,
                'perpustakaan_pinjam_id' => $pee->id,
            ];

            $perpustakaan_rinci = Perpustakaan_Pinjam_Rincian::create($create);
        }

        return response()->json([
            'data' => [
                'id_pinjam' => $pee->id
            ],
        ], 201);
    }

    public function ebook(Request $request)
    {
        $file_path = 'https://dapurkoding.my.id/';
        $kategori = Buku_Kategori::get();
        $katfirst = Buku_Kategori::first();
        $bukurel = BukuRelasiKategori::where('buku_kategori_id', $katfirst->id)->get();
        $datakategori = [];
        $tam = [];
        foreach ($kategori as $p) {
            $k['id_kategori'] = $p->id;
            $k['judul_kategori'] = $p->nama_kategori;
            $k['avatar'] = $file_path . 'gambarkategori/' . $p->gambar;
            array_push($datakategori, $k);
            $bukuedsdsds = BukuRelasiKategori::where('buku_kategori_id', $p->id)->get();
            // dd($buku);
            $tambuku = [];
            foreach ($bukuedsdsds as $bukurrrrr) {
                $bukur = Buku::where('id', $bukurrrrr->buku_id)->where('jenis', 'ebook')->first();
                if ($bukur != null) {
                    $buku['id_buku'] = $bukur->id;
                    $buku['penulis'] = $bukur->penulis;
                    $buku['judul_buku'] = $bukur->judul;
                    $buku['jenis'] = $bukur->jenis;
                    // $tampungnamakategori = [];
                    $datakat = [];
                    $tampungnamakategori = BukuRelasiKategori::where('buku_id', $bukur->id)->get();
                    foreach ($tampungnamakategori as $tama) {
                        array_push($datakat, Buku_Kategori::where('id', $tama->buku_kategori_id)->first()->nama_kategori);
                    }
                    $buku['kat'] = $datakat;
                    $buku['avatar'] = $file_path . 'sampul/' . $bukur->sampul;
                    $buku['view'] = (int)$bukur->view;
                    array_push($tambuku, $buku);
                }
            }

            $row['id_kategori'] = $p->id;
            $row['judul_kategori'] = $p->nama_kategori;
            $row['buku'] = $tambuku;
            // $row['kategori'] = Buku_Kategori::where('id', $p->id)->first();
            array_push($tam, $row);
        }
        // dd($tam);
        // dd($tam);

        return response()->json([
            'menu' => $datakategori,
            'kategori' => $tam
        ]);
        // dd($

    }

    public function fisik(Request $request)
    {
        $file_path = 'https://dapurkoding.my.id/';
        $kategori = Buku_Kategori::get();
        $katfirst = Buku_Kategori::first();
        $bukurel = BukuRelasiKategori::where('buku_kategori_id', $katfirst->id)->get();
        $datakategori = [];
        $tam = [];
        foreach ($kategori as $p) {
            $k['id_kategori'] = $p->id;
            $k['judul_kategori'] = $p->nama_kategori;
            $k['avatar'] = $file_path . 'gambarkategori/' . $p->gambar;
            array_push($datakategori, $k);
            $bukuedsdsds = BukuRelasiKategori::where('buku_kategori_id', $p->id)->get();
            // dd($buku);
            $tambuku = [];
            foreach ($bukuedsdsds as $bukurrrrr) {
                $bukur = Buku::where('id', $bukurrrrr->buku_id)->where('jenis', 'fisik')->first();
                if ($bukur != null) {
                    $buku['id_buku'] = $bukur->id;
                    $buku['penulis'] = $bukur->penulis;
                    $buku['judul_buku'] = $bukur->judul;
                    $buku['jenis'] = $bukur->jenis;
                    // $tampungnamakategori = [];
                    $datakat = [];
                    $tampungnamakategori = BukuRelasiKategori::where('buku_id', $bukur->id)->get();
                    foreach ($tampungnamakategori as $tama) {
                        array_push($datakat, Buku_Kategori::where('id', $tama->buku_kategori_id)->first()->nama_kategori);
                    }
                    $buku['kat'] = $datakat;
                    $buku['avatar'] = $file_path . 'sampul/' . $bukur->sampul;
                    $buku['view'] = (int)$bukur->view;
                    array_push($tambuku, $buku);
                }
            }

            $row['id_kategori'] = $p->id;
            $row['judul_kategori'] = $p->nama_kategori;
            $row['buku'] = $tambuku;
            // $row['kategori'] = Buku_Kategori::where('id', $p->id)->first();
            array_push($tam, $row);
        }
        // dd($tam);
        // dd($tam);

        return response()->json([
            'menu' => $datakategori,
            'kategori' => $tam
        ]);
        // dd($
    }

    public function detailpinjambuku(Request $request)
    {
        $file_path = 'https://dapurkoding.my.id/';
        $id_pinjam = $request->id_pinjam;
        $perpustakaan_pinjam = Perpustakaan_Pinjam::where('id', $id_pinjam)->first();
        $perpustakaan_pinjam_detail = Perpustakaan_Pinjam_Rincian::where('perpustakaan_pinjam_id', $perpustakaan_pinjam->id)->get();
        $tampungdata = [];
        foreach ($perpustakaan_pinjam_detail as $detail) {
            $row['id_buku'] = $detail->buku_id;
            $row['penulis'] = $detail->relasiBuku->penulis;
            $row['judul_buku'] = $detail->relasiBuku->judul;
            $row['jenis'] = $detail->relasiBuku->jenis;
            $bukurel = BukuRelasiKategori::where('buku_id', $detail->buku_id)->get();
            $tampungnamakategori = [];
            foreach ($bukurel as $kat) {
                array_push($tampungnamakategori, Buku_Kategori::where('id', $kat->buku_kategori_id)->first()->nama_kategori);
            }
            $row['kat'] = $tampungnamakategori;
            $row['avatar'] = $file_path . 'sampul/' . $detail->relasiBuku->sampul;
            $row['view'] = (int)$detail->relasiBuku->view;
            array_push($tampungdata, $row);
        }
        return response()->json([
            'id_pinjam' => "$id_pinjam",
            'detail_pinjam' => [
                'waktu_pinjam' => $perpustakaan_pinjam->tanggal_peminjaman,
                'batas_waktu' => $perpustakaan_pinjam->batas_waktu,
                'buku' => $tampungdata,
                'catatan' => $detail->note
            ],
        ]);
        // dd($tampungdata);
    }

    public function bukuperpus(Request $request)
    {

        $file_path = 'https://dapurkoding.my.id/';
        $id_buku = (int)$request->id_buku;

        $bukurelasi = BukuRelasiKategori::where('buku_id', $id_buku)->first();
        $kategori = Buku_Kategori::where('id', $bukurelasi->buku_kategori_id)->first();
        // dd($kategori);
        $buku = Buku::where('id', $id_buku)->first();
        $row['id'] = $buku->id;
        $row['kategori'] = $kategori->nama_kategori;
        $row['judul'] = $buku->judul;
        $row['penulis'] = $buku->penulis;
        $row['avatar'] = $file_path . 'sampul/' . $buku->sampul;
        $row['sinopsis'] = $buku->sinopsis;
        $row['jml_hal'] = $buku->jumlah_halaman;
        $row['bahasa'] = $buku->bahasa;
        $row['penerbit'] = $buku->penerbit;
        $row['isbn'] = $buku->isbn_no;
        $row['jenis'] = $buku->jenis;
        if ($buku->jenis === 'ebook') {
            $row['pinjam'] = false;
            $row['link'] = $file_path . 'ebook/' . $buku->jenis;
        } else {
            $row['pinjam'] = true;
            $row['link'] = '';
        }
        return response()->json([
            'detail_buku' => $row
        ]);
    }

    public function caribuku(Request $request)
    {

        $kategori = Buku_Kategori::get();
        $tampungdata = [];
        foreach ($kategori as $kat) {
            $buk['id_kategori'] = "$kat->id";
            $buk['kategori'] = $kat->nama_kategori;
            array_push($tampungdata, $buk);
        }
        return response()->json([
            'jenis_buku' =>  [
                [
                    "id_jenis" => "001",
                    "jenis" => "ebook"
                ],
                [
                    "id_jenis" => "002",
                    "jenis" => "fisik"
                ]
            ],
            'kategori_buku' => $tampungdata
        ]);
    }

    public function perpustakaankategori(Request $request)
    {
        $file_path = 'https://dapurkoding.my.id/';
        $bukurel = BukuRelasiKategori::where('buku_kategori_id', $request->id_kategori)->get();
        $tampungnamakategori = [];
        $tampungkategori = [];
        $tampungdata = [];

        foreach ($bukurel as $index => $kat) {
            $buku = Buku::where('id', $kat->buku_id)->first();
            $row['id_buku'] = $buku->id;
            $row['penulis'] = $buku->penulis;
            $row['judul_buku'] = $buku->judul;
            $row['jenis'] = $buku->jenis;
            $bukurel = BukuRelasiKategori::where('buku_id', $buku->id)->get();
            if ($bukurel != null) {
                $tampungnamakategori = [];
                foreach ($bukurel as $kat) {
                    array_push($tampungnamakategori, Buku_Kategori::where('id', $kat->buku_kategori_id)->first()->nama_kategori);
                }
            }
            $row['kat'] = $tampungnamakategori;
            $row['avatar'] = $file_path . 'sampul/' . $buku->sampul;
            $row['view'] = (int)$buku->view;
            array_push($tampungdata, $row);
            // array_push($tampungkategori, $buku);
            // array_push($tampungnamakategori, );
        }
        // dd(count($tampungdata));
        $halaman = (int)$request->halaman;
        // dd($tampungdata);
        $tes = [];
        for ($i = $halaman * 2 - 2; $i < $halaman * 2; $i++) {
            if ($halaman * 2 <= count($tampungdata)) {
                array_push($tes, $tampungdata[$i]);
            }
            // dd($tampungkategori[$i]);
        }
        // dd($tes);
        return response()->json([
            'halaman' => $halaman,
            'buku' => $tes
        ]);
        // foreach ($tampungdatabuku as $buku) {
        //     $kategori['id_buku'] = $buku->id;
        //     $kategori['penulis'] = $buku->penulis;
        //     $kategori['judul_buku'] = $buku->judul;
        //     $kategori['jenis'] = $buku->jenis;
        //     $bukurel = BukuRelasiKategori::where('buku_id', $buku->id)->get();
        //     $tampungnamakategori = [];
        //     foreach ($bukurel as $kat) {
        //         array_push($tampungnamakategori, Buku_Kategori::where('id', $kat->buku_kategori_id)->first()->nama_kategori);
        //     }
        //     $kategori['kat'] = $tampungnamakategori;
        //     $kategori['avatar'] = $file_path . 'sampul/' . $buku->sampul;
        //     $kategori['view'] = (int)$buku->view;
        //     array_push($tampungkategori, $kategori);
        // }
    }
}
