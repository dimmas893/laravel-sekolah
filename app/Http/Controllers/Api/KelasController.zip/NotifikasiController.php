<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Hari;
use App\Models\Siswa;
use App\Models\Invoice_Tagihan;
use App\Models\Perpustakaan_Pinjam;
use App\Models\Perpustakaan_Pinjam_Rincian;
use App\Models\PerpustakaanMember;
use Carbon\Carbon;
use Illuminate\Http\Request;

class NotifikasiController extends Controller
{
    public function notifikasi(Request $request)
    {
        $myDate = Carbon::today()->format('Y-m-d');
        // $namaHari = Carbon::createFromFormat('Y-m-d', $myDate)->format('l');
        // $namaHari = Carbon::today()->format('dddd');
        $besok = Carbon::now()->add(3, 'day')->format('Y-m-d');
        // $tanggalhariini = Carbon::now()->format('Y-m-d');
        $namaHari = Carbon::now()->isoFormat('dddd');
        // dd($besok);
        $hariJadwal = Hari::where('name', $namaHari)->first();
        // dd($hariJadwal);
        $dataNotifikasi = [];
        $idUser = $request->id_user;
        $siswa = Siswa::where('id_user', $idUser)->first();
        if ($siswa) {
            $idSiswa = $siswa->id;
            $member = PerpustakaanMember::where('user_id', $idUser)->where('status_aktif', 1)->first();
            if ($member) {
                $pengembalian_buku = Perpustakaan_Pinjam::where('member_id', $member->id)->get();

                foreach ($pengembalian_buku->where('batas_waktu', $besok) as $pengembalian) {
                    // dd($pengembalian);
                    $row['id'] = $pengembalian->id;
                    $rincian_buku = Perpustakaan_Pinjam_Rincian::where('perpustakaan_pinjam_id', $pengembalian->id)->count();
                    $databuku = Perpustakaan_Pinjam_Rincian::with('relasiBuku')->where('perpustakaan_pinjam_id', $pengembalian->id)->first();
                    // dd($databuku);
                    $row['nama'] = 'Kembalikan buku' . $databuku['relasiBuku']['judul'] . ' dan ' . $rincian_buku . ' buku lainnya';
                    $row['subnama'] = 'Pengembalian Buku';
                    $row['deskripsi'] = 'ini Adalah Notifikasi Tanggal Pengembalian Buku siswa';
                    $row['tgl_notifikasi'] = $myDate;
                    $row['target'] = 'Pengembalian Buku';
                    $row['id_target'] = 0;
                    $row['read'] = 0;
                    array_push($dataNotifikasi, $row);
                }
            }

            $tagihanSiswa = Invoice_Tagihan::where('id_siswa', $idSiswa)->where('status', 'unpaid')->get();
            if ($tagihanSiswa) {
                foreach ($tagihanSiswa as $tagihan) {
                    $row['id'] = $tagihan->id;
                    $row['nama'] = $tagihan->kategori_tagihan->deskripsi;
                    $row['subnama'] = 'tagihan';
                    $row['deskripsi'] = 'ini adalah tagihan siswa';
                    $row['tgl_notifikasi'] = $myDate;
                    $row['target'] = $tagihan->kategori_tagihan->kategori_tagihan->nama_kategori;
                    $row['id_target'] = 0;
                    $row['read'] = 0;
                    array_push($dataNotifikasi, $row);
                }
            }

            if (count($dataNotifikasi) > 0) {
                return response()->json([
                    'notifikasi' => $dataNotifikasi
                ]);
            } else {
                return response()->json([
                    'notifikasi' => 'Data Tidak Tersedia'
                ]);
            }
        } else {
            return response()->json([
                'error' => 'Data Siswa Tidak Ada'
            ], 404);
        }
    }
}
