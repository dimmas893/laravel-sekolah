<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Absen;
use App\Models\Invoice_Tagihan;
use App\Models\Kategori_Tagihan;
use App\Models\Kumpul_Tugas;
use App\Models\Mata_Pelajaran;
use App\Models\Nilai;
use App\Models\Rincian_Pembayaran;
use App\Models\Semester;
use App\Models\Setting;
use App\Models\Siswa;
use App\Models\Tagihan_Siswa;
use App\Models\Tahun_ajaran;
use App\Models\Ujian;
use Illuminate\Http\Request;
use PDF;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

class LaporanController extends Controller
{
    public function laporanKeuangan(Request $request)
    {
        $file_path = 'https://dapurkoding.my.id/';
        $mulai = $request->mulai;
        $selesai = $request->selesai;
        $siswa = Siswa::where('nomor_induk_siswa', $request->id_siswa)->first();
        $namaFile = 'Laporan_keuangan_' . $siswa->nomor_induk_siswa . $mulai . '_' . $selesai  . '.pdf';
        $kategoritagihan = Kategori_Tagihan::where('id', $request->id_kategori)->first();
        $TagihanSiswa = Tagihan_Siswa::where('id_kategori_tagihan', $kategoritagihan->id)->get();
        $tampung = [];
        foreach ($TagihanSiswa as $tagihanSis) {
            $invoice = Invoice_Tagihan::where('id_siswa', $siswa->id)->where('id_tagihan', $tagihanSis->id)->first();
            if ($invoice) {
                if ($invoice->status === 'paid') {
                    $pembayaran = Rincian_Pembayaran::whereBetween('tanggal_pembayaran', [$mulai, $selesai])->where('id_invoice', $invoice->id_invoice)->get();
                    // dd($pembayaran);
                    foreach ($pembayaran as $pem) {
                        $row['kategori_tagihan'] = $tagihanSis['kategori_tagihan']['nama_kategori'];
                        $row['nominal'] = $invoice['nominal'];
                        array_push($tampung, $row);
                    }
                }
            }
        }
        $pdf = PDF::loadView('pdf.periode', compact('tampung'));
        $pdf->save(public_path() . '/simpanPDF/' . $namaFile);
        // dd($tampung);
        return response()->json([
            'url' => $file_path . 'simpanPDF/' . $namaFile
        ], 200);
    }

    public function laporanabsenpdf(Request $request)
    {
        $file_path = 'https://dapurkoding.my.id/';
        $mulai = $request->mulai;
        $selesai = $request->selesai;
        $setting = Setting::first();
        $siswa = Siswa::where('id_user', $request->id_siswa)->first();
        // $absen = Absen::where('tahun_ajaran', $setting->id_tahun_ajaran)->where('siswa_id', $siswa->id)->where('semester', $setting->semester)->where('tanggal', $request->tanggal)->get();
        $hadir = Absen::where('tahun_ajaran', $setting->id_tahun_ajaran)->where('siswa_id', $siswa->id)->where('semester', $setting->semester)->whereBetween('tanggal', [$mulai, $selesai])->where('tipe_kehadiran', '0')->count();
        $sakit = Absen::where('tahun_ajaran', $setting->id_tahun_ajaran)->where('siswa_id', $siswa->id)->where('semester', $setting->semester)->whereBetween('tanggal', [$mulai, $selesai])->where('tipe_kehadiran', '1')->count();
        $izin = Absen::where('tahun_ajaran', $setting->id_tahun_ajaran)->where('siswa_id', $siswa->id)->where('semester', $setting->semester)->whereBetween('tanggal', [$mulai, $selesai])->where('tipe_kehadiran', '2')->count();
        $alpha = Absen::where('tahun_ajaran', $setting->id_tahun_ajaran)->where('siswa_id', $siswa->id)->where('semester', $setting->semester)->whereBetween('tanggal', [$mulai, $selesai])->where('tipe_kehadiran', '3')->count();
        $namaFile = 'Laporan_absensi_' . $siswa->nomor_induk_siswa . $mulai . '_' . $selesai  . '.pdf';
        $pdf = PDF::loadView('pdf.laporanabsenpdf', compact('siswa', 'hadir', 'sakit', 'izin', 'alpha'));
        $pdf->save(public_path() . '/simpanPDF/' . $namaFile);
        // dd($tampung);
        return response()->json([
            'url' => $file_path . 'simpanPDF/' . $namaFile
        ], 200);
    }

    public function laporannilai(Request $request)
    {
        // dd($request->all());
        $file_path = 'https://dapurkoding.my.id/';
        $mulai = $request->mulai;
        $selesai = $request->selesai;
        $tahun_ajaranmulai = Tahun_ajaran::where('tahun_ajaran', substr($mulai, 0, 4))->first();
        $tahun_ajaranselesai = Tahun_ajaran::where('tahun_ajaran', substr($selesai, 0, 4))->first();
        $settingmulai = Setting::where('id_tahun_ajaran', $tahun_ajaranmulai->id)->first();
        $settingselesai = Setting::where('id_tahun_ajaran', $tahun_ajaranselesai->id)->first();
        $siswa = Siswa::where('id_user', $request->id_siswa)->first();
        // dd($siswa);
        if ($settingmulai != null && $settingselesai != null) {
            $matapelajaran = Mata_Pelajaran::where('tingkatan', $siswa->tingkat)->where('jurusan', $siswa->jurusan)->select('id')->groupBy('id')->get();
            $tampungujian = [];
            $scoreuts = [];
            $scoreuas = [];
            $id = $siswa->id;
            foreach ($matapelajaran as $mata) {
                $matamata = $mata->id;
                $ujian = Ujian::where('tahun_ajaran_id', $settingmulai->id_tahun_ajaran)->where('mata_pelajaran_id', $mata->id)->get();
                foreach ($ujian as $uji) {
                    // dd($uji->jenis_ujian);
                    if ($uji['jenis_ujian'] === 'uas') {
                        $ceknilai = Nilai::where('ujian_id', $uji->id)->where('siswa_id', $siswa->id)->first();
                        // $row['uas'] = $ceknilai['score'];
                        // $row['uts'] = (int)$ceknilai['score'];
                        array_push($scoreuas, (int)$ceknilai['score']);
                    }
                    if ($uji['jenis_ujian'] === 'uts') {
                        $ceknilai = Nilai::where('ujian_id', $uji->id)->where('siswa_id', $siswa->id)->first();
                        array_push($scoreuts, (int)$ceknilai['score']);
                    }
                }
                if (count($scoreuas) > 0) {
                    $row['uas'] = array_sum($scoreuas) / count($scoreuas);
                } else {
                    $row['uas'] = 0;
                }
                if (count($scoreuts) > 0) {
                    $row['uts'] = array_sum($scoreuts) / count($scoreuts);
                } else {
                    $row['uts'] = 0;
                }

                $row['matapelajaran'] = Mata_Pelajaran::where('id', $mata->id)->first()->name;
                $hitung = Kumpul_Tugas::whereHas('tugas', function ($q) use ($matamata, $mulai, $selesai) {
                    $q->whereBetween('tanggal_tugas', [$mulai, $selesai])->where('mata_pelajaran_id', $matamata);
                })->where('siswa_id', $siswa->id)->count();

                $sum = Kumpul_Tugas::whereHas('tugas', function ($q) use ($matamata, $mulai, $selesai) {
                    $q->whereBetween('tanggal_tugas', [$mulai, $selesai])->where('mata_pelajaran_id', $matamata);
                })->where('siswa_id', $siswa->id)->sum('nilai_tugas');
                // dd($hitung);
                // (int)$sum / $hitung;
                if ($sum > 0 && $hitung > 0) {
                    $row['tugas'] = (int)$sum / (int)$hitung;
                } else {
                    $row['tugas'] = 0;
                }
                array_push($tampungujian, $row);
            }
            dd($tampungujian);
            // dd($hasil);
            $namaFile = 'Laporan_Nilai_' . $siswa->nomor_induk_siswa . '.pdf';
            $pdf = PDF::loadView('pdf.laporannilai', compact('tampungujian'));
            $pdf->save(public_path() . '/simpanPDF/' . $namaFile);
            // dd($tampung);
            return response()->json([
                'url' => $file_path . 'simpanPDF/' . $namaFile
            ], 200);
        } else {
            return response()->json([
                'error' => ['tanggal harus tahun ajaran yang berjalan']
            ], 404);
        }
    }

    public function periode(Request $request)
    {
        // dd($request->all());
        $file_path = 'https://dapurkoding.my.id/';
        $mulai = $request->mulai;
        $selesai = $request->selesai;
        $siswa = Siswa::where('nomor_induk_siswa', $request->id_siswa)->first();
        $namaFile = 'Laporan_keuangan_' . $siswa->nomor_induk_siswa . $mulai . '_' . $selesai  . '.pdf';
        $kategoritagihan = Kategori_Tagihan::where('id', $request->id_kategori)->first();
        $TagihanSiswa = Tagihan_Siswa::where('id_kategori_tagihan', $kategoritagihan->id)->get();
        $tampung = [];
        foreach ($TagihanSiswa as $tagihanSis) {
            $invoice = Invoice_Tagihan::where('id_siswa', $siswa->id)->where('id_tagihan', $tagihanSis->id)->first();
            if ($invoice) {
                if ($invoice->status === 'paid') {
                    $pembayaran = Rincian_Pembayaran::whereBetween('tanggal_pembayaran', [$mulai, $selesai])->where('id_invoice', $invoice->id_invoice)->get();
                    // dd($pembayaran);
                    foreach ($pembayaran as $pem) {
                        $row['kategori_tagihan'] = $tagihanSis['kategori_tagihan']['nama_kategori'];
                        $row['nominal'] = $invoice['nominal'];
                        array_push($tampung, $row);
                    }
                }
            }
        }
        $pdf = PDF::loadView('pdf.periode', compact('tampung'));
        $pdf->save(public_path() . '/simpanPDF/' . $namaFile);
        // dd($tampung);
        return response()->json([
            'url' => $file_path . 'simpanPDF/' . $namaFile
        ], 200);
    }

    public function laporanabsen(Request $request)
    {
        $file_path = 'http://dapurkoding.my.id/';
        $tahun = Setting::first()->id_tahun_ajaran;
        $siswa = Siswa::where('id_user', $request->id_user)->first();
        $absen = Absen::where('siswa_id', $siswa->id)->select(DB::raw('YEAR(tanggal) year, MONTH(tanggal) month'))->groupby('year', 'month')->get();
        $tampungtanggal = [];
        foreach ($absen as $abs) {
            $TanggalAsli = Absen::where('siswa_id', $siswa->id)->whereMonth('tanggal', $abs->month)->whereYear('tanggal', $abs->year)->first()->tanggal;
            $row['bulan'] = Carbon::createFromFormat('Y-m-d', $TanggalAsli)->isoFormat("MMMM") . ' ' . Carbon::createFromFormat('Y-m-d', $TanggalAsli)->isoFormat("Y");
            $row['tgl_mulai'] = Absen::where('siswa_id', $siswa->id)->whereMonth('tanggal', $abs->month)->whereYear('tanggal', $abs->year)->orderBy('tanggal', 'ASC')->first()->tanggal;
            $row['tgl_akhir'] = Absen::where('siswa_id', $siswa->id)->whereMonth('tanggal', $abs->month)->whereYear('tanggal', $abs->year)->orderBy('tanggal', 'DESC')->first()->tanggal;
            array_push($tampungtanggal, $row);
        }
        // dd($tampungtanggal);
        if ($siswa) {
            return response()->json([
                "siswa" => [[
                    'id' => strval($request->id_user),
                    'name' => $siswa->nama_siswa,
                    'avatar' =>  $file_path . 'avatar/' . $siswa->avatar
                ]],
                "periode" => $tampungtanggal
            ]);
        }
    }
}
