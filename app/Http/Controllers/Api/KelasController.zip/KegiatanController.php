<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Gambar_Kegiatan;
use App\Models\Kegiatan;
use App\Models\Lampiran_Kegiatans;
use Illuminate\Http\Request;

class KegiatanController extends Controller
{
    public function kegiatandetail(Request $request)
    {
        $kegiatan = Kegiatan::where('id', $request->id_kegiatan)->first();
        // dd($kegiatan);
        if ($kegiatan) {
            $tampungkegiatan = [];
            $kegiatans['id'] = $kegiatan['id'];
            // $kegiatans['nama'] = $kegiatan['nama_kegiatan'];
            $kegiatans['tanggal'] = $kegiatan['tanggal'];
            $kegiatans['waktu'] = $kegiatan['jam_mulai'] . ' - ' . $kegiatan['jam_berakhir'];
            $kegiatans['deskripsi'] = $kegiatan['deskripsi'];
            $kegiatans['catatan'] = $kegiatan['catatan'];
            array_push($tampungkegiatan, $kegiatans);
            $kegiatans['contact_person']['nama'] = $kegiatan['nama'];
            $kegiatans['contact_person']['kontak'] = $kegiatan['kontak'];
            $kegiatans['contact_person']['jenis_kontak'] = $kegiatan['jenis_kontak'];
            $kegiatans['gambar'] = [];
            $kegiatans['lampiran'] = [];
            $gambarKegiatan = Gambar_Kegiatan::where('kegiatan_id', $kegiatan->id)->get();
            if ($gambarKegiatan) {
                foreach ($gambarKegiatan as $gambar) {
                    array_push($kegiatans['gambar'], $gambar['gambar']);
                }
            }
            $kegiatans['lampiran'] = [];
            $LampiranKegiatan = Lampiran_Kegiatans::where('kegiatan_id', $kegiatan->id)->get();
            if ($LampiranKegiatan) {
                foreach ($LampiranKegiatan as $lampiran) {
                    $lampirans['nama'] = $lampiran['nama'];
                    $lampirans['link'] = $lampiran['lampiran_kegiatan'];
                    array_push($kegiatans['lampiran'], $lampirans);
                }
            }
            return response()->json([
                "detail_kegiatan" => $kegiatans
            ]);
        }
    }
}
